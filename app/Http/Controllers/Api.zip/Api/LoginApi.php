<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\User;
use DB;


class LoginApi extends Controller
{

	public function login(Request $request)
	{
		$credentials = $request->only('email', 'password');
		if (Auth::attempt($credentials)) {
			$data = DB::table('users')
			->where('email' ,'=' , $credentials)
			->get();
			return response()->json([
				'username' => $data,
				'status_code'   => 200,
				'msg'           => 'success',
			], 200);
		}else{
			return response()->json([
				'username' => 'data tidak ditemukan',
				'status_code'   => 200,
				'msg'           => 'not found',
			], 200);
		}
	}
	public function register(Request $request){
		$data = new User;
		$data->name = $request->name;
		$data->email = $request->email;	
		$data->notelp = $request->notelp;
		$data->password = Hash::make($request->password);
		$data->id_data = bin2hex(random_bytes(20));
		$data->save();
		
		return response()->json([
			'register' => $data,
			'status_code'   => 200,
			'msg'           => 'Berhasil Registrasi',
		], 201);
	}
	
}
