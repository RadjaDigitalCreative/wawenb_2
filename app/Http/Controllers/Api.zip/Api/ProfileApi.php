<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class ProfileApi extends Controller
{
    public function index()
    {
        $data = DB::table('users')
        ->get();
        return response()->json([
            'users' => $data,
            'status_code'   => 200,
            'msg'           => 'success',
        ], 200);
    }
    public function get($id)
    {
        $data = DB::table('users')
        ->where('id', $id)
        ->get();
        return response()->json([
            'users' => $data,
            'status_code'   => 200,
            'msg'           => 'success',
        ], 200);

    }
    public function update($id, Request $request)
    {
        $data = DB::table('users')
        ->where('id', $id)
        ->update([
            'name' => $request->name,
            'email' => $request->email,
            'bio' => $request->bio,
            'notelp' => $request->notelp,
        ]);
      
        return response()->json([
            'users' => $data,
            'status_code'   => 200,
            'msg'           => 'success',
        ], 200);

    }
}
