<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\WaImport;
use App\Jobs\ImportJob;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\URL;
use Maatwebsite\Excel\Concerns\ToModel;

use DB;

class WaApi extends Controller
{
    public function index()
    {
        $data = DB::table('wa')
        ->where('name', '!=', 'NAMA')
        ->where('status',  NULL )
        ->get();
        return response()->json([
            'Wa Blast Data' => $data,
            'status_code'   => 200,
            'msg'           => 'success',
        ], 200);
    }
    public function get($id)
    {
        $data = DB::table('wa')
        ->where('name', '!=', 'NAMA')
        ->where('status',  NULL )
        ->where('id',  $id )
        ->get();
        return response()->json([
            'Wa Blast Data' => $data,
            'status_code'   => 200,
            'msg'           => 'success',
        ], 200);
    }
    public function destroy($id)
    {
        $data = DB::table('wa')
        ->where('id', $id)
        ->delete();
        return response()->json([
            'Wa Blast Data' => 'Data Berhasil Dihapus',
            'status_code'   => 200,
            'msg'           => 'success',
        ], 200);
    }
    public function import(Request $request)
    {
        $data = Excel::toArray(new WaImport, $request->file('file'));
        $id_wa= [];
        foreach ($data[0] as $key => $value) {
            $id_wa[] = $value[1];
        }
        $hitung = count($id_wa);
        for ($i=0; $i < $hitung; $i++) { 
            DB::table('role')
            ->insert([
                'id_wa'  => $id_wa[$i],
                'id_data'  => $request->role,
            ]);
        }

        Excel::import(new WaImport,request()->file('file'));
        return response()->json([
            'Wa Blast Data' => 'Data Berhasil Diimport',
            'status_code'   => 200,
            'msg'           => 'success',
        ], 200);
    }
}
